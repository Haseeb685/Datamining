import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_selection import SelectFromModel
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE  # Install imbalanced-learn if not available
import pickle

# Load Dataset
file_path = "Train_phone.csv"  # Path to the uploaded dataset
data = pd.read_csv(file_path)

# Step 1: Data Preprocessing
# Fill missing values in numerical columns with their median
numerical_cols = data.select_dtypes(include=["float64", "int64"]).columns
data[numerical_cols] = data[numerical_cols].fillna(data[numerical_cols].median())

# Encode categorical columns
categorical_cols = data.select_dtypes(include=["object"]).columns
label_encoders = {col: LabelEncoder() for col in categorical_cols}

import pickle

for col in categorical_cols:
    data[col] = label_encoders[col].fit_transform(data[col])

    # Save the label encoder for the 'store' feature specifically
    if col == "store":
        with open("label_encoder_store.pkl", "wb") as file:
            pickle.dump(label_encoders[col], file)
            print("Label encoder for 'store' saved as 'label_encoder_store.pkl'.")

# Print label names and their encoding for each categorical column
for col in categorical_cols:
    if col  == "store":
        print(f"Label encoding for column '{col}':")
        labels = label_encoders[col].classes_  # Get the unique classes
        encoding = label_encoders[col].transform(labels)  # Get the encoding for each class
        for label, enc in zip(labels, encoding):
            print(f"Label: {label}, Encoding: {enc}")
    print()  # Newline for better readability

# Step 2: Feature Selection
if "price_range" in data.columns:
    X = data.drop(columns=["price_range"], errors="ignore")
    y = data["price_range"]

    # Use RandomForest to determine feature importance
    feature_selector = RandomForestClassifier(random_state=42)
    feature_selector.fit(X, y)

    # Get feature importances and select top features
    feature_importances = pd.DataFrame(
        {"Feature": X.columns, "Importance": feature_selector.feature_importances_}
    ).sort_values(by="Importance", ascending=False)

    # Select the top N features (e.g., top 4 features)
    top_features = feature_importances.head(4)["Feature"].tolist()
    print("Top Selected Features:\n", feature_importances.head(4))

    X = X[top_features]

    # Step 3: Train-Test Split and Balancing
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )

    # Balance the training data using SMOTE
    smote = SMOTE(random_state=42)
    X_train_balanced, y_train_balanced = smote.fit_resample(X_train, y_train)

    print("Original class distribution in training set:")
    print(y_train.value_counts())
    print("\nBalanced class distribution in training set:")
    print(pd.Series(y_train_balanced).value_counts())

    # Step 4: Apply StandardScaler only to the selected features
    scaler = StandardScaler()

    # Fit and transform on the training data
    X_train_balanced[top_features] = scaler.fit_transform(
        X_train_balanced[top_features]
    )

    # Transform the test data using the same scaler
    X_test[top_features] = scaler.transform(X_test[top_features])

    # Save the scaler
    with open("scaler.pkl", "wb") as scaler_file:
        pickle.dump(scaler, scaler_file)

    print("Scaler saved successfully.")

    # Step 5: Train and evaluate classifiers
    classifiers = {
        "Logistic Regression": LogisticRegression(),
        "Decision Tree": DecisionTreeClassifier(),
        "Random Forest": RandomForestClassifier(),
        "SVM": SVC(probability=True),
        "XGBoost": XGBClassifier(),
    }

    # Dictionary to store F1 scores of all models
    f1_scores = {}

    # Train and evaluate each classifier
    best_model = None
    best_f1_score = 0
    best_model_name = ""

    for name, clf in classifiers.items():
        clf.fit(X_train_balanced, y_train_balanced)
        y_pred = clf.predict(X_test)
        f1 = f1_score(y_test, y_pred, average="weighted")
        f1_scores[name] = f1

        # Update the best model if current model's F1 score is better
        if f1 > best_f1_score:
            best_f1_score = f1
            best_model = clf
            best_model_name = name

        # Print metrics for the current classifier
        print(f"\nClassifier: {name}")
        print("Accuracy:", accuracy_score(y_test, y_pred))
        print("Precision:", precision_score(y_test, y_pred, average="weighted"))
        print("Recall:", recall_score(y_test, y_pred, average="weighted"))
        print("F1 Score:", f1)
        print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
        print("Classification Report:\n", classification_report(y_test, y_pred))

    # Save the best-performing model
    if best_model:
        with open("best_model.pkl", "wb") as model_file:
            pickle.dump(best_model, model_file)
        print(
            f"\nBest model '{best_model_name}' saved with F1 Score: {best_f1_score:.4f}"
        )
    else:
        print("No model was identified as the best model.")
