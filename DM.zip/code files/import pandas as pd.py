import pandas as pd
from sklearn.model_selection import train_test_split

# Load the dataset
file_path = 'C:/Users/UNKNOWN/Desktop/phone.csv'  # Path to the uploaded file
data = pd.read_csv(file_path)

# Split the dataset
train_data, test_data = train_test_split(data, test_size=0.2, random_state=42, stratify=data['price_range'])

# Save the train and test splits as separate files
train_data.to_csv('Train_phone.csv', index=False)
test_data.to_csv('Test_phone.csv', index=False)

print("Dataset split completed.")
print("Training set saved as 'Train_phone.csv'")
print("Testing set saved as 'Test_phone.csv'")
