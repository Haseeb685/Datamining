from flask import Flask, render_template, request
import pandas as pd
import pickle

app = Flask(__name__)

# Load the saved model
with open("best_model.pkl", "rb") as model_file:
    best_model = pickle.load(model_file)

# Load the saved scaler
with open("scaler.pkl", "rb") as scaler_file:
    scaler = pickle.load(scaler_file)

# Load the saved label encoder for the 'store' feature
with open("label_encoder_store.pkl", "rb") as encoder_file:
    store_encoder = pickle.load(encoder_file)


@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    if request.method == "POST":
        # Get the input data from the form
        input_data = {
            "price_USD": request.form["price_USD"],
            "price": request.form["price"],
            "store": request.form["store"],  # Example input for 'store'
            "Weight": request.form["Weight"],
        }
        print(input_data)
        # Encode the 'store' feature using the label encoder
        input_data["store"] = store_encoder.transform([input_data["store"]])[0]

        # Convert input data to DataFrame (for scaling)
        data = pd.DataFrame([input_data])

        # Scale the input data
        data = scaler.transform(data)

        # Make prediction using the loaded model
        prediction = best_model.predict(data)[0]

        labels = ["low price", "medium price", "high price"]

        prediction = labels[prediction - 1]

    return render_template("index.html", prediction=prediction)


if __name__ == "__main__":
    app.run(debug=True)
