import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE

# Load Dataset
data = pd.read_csv('Train_phone.csv')  # Replace 'Train_phone.csv' with the actual file path

# Step 1: Data Preprocessing
# Fill missing values in numerical columns with their median
numerical_cols = data.select_dtypes(include=['float64', 'int64']).columns
data[numerical_cols] = data[numerical_cols].fillna(data[numerical_cols].median())

# Encode categorical columns
categorical_cols = data.select_dtypes(include=['object']).columns
label_encoders = {col: LabelEncoder() for col in categorical_cols}
for col in categorical_cols:
    data[col] = label_encoders[col].fit_transform(data[col])

# Scale numerical features
scaler = StandardScaler()
data[numerical_cols] = scaler.fit_transform(data[numerical_cols])

# Identify the target column
target_column = 'price_range'
if target_column not in data.columns:
    raise ValueError(f"Target column '{target_column}' not found in the dataset")

# Separate features and target
features = data.drop(columns=[target_column])
target = data[target_column]

# Step 2: Balance the Dataset
# Use SMOTE to oversample the minority class
smote = SMOTE(random_state=42)
features_balanced, target_balanced = smote.fit_resample(features, target)

# Step 3: Feature Selection using RandomForest
# Use RandomForest to determine feature importance
feature_selector = RandomForestClassifier(random_state=42)
feature_selector.fit(features_balanced, target_balanced)

# Get feature importances and select top features
feature_importances = pd.DataFrame(
    {"Feature": features.columns, "Importance": feature_selector.feature_importances_}
).sort_values(by="Importance", ascending=False)



# Step 4: Splitting the Dataset
X_train, X_test, y_train, y_test = train_test_split(features_balanced, target_balanced, test_size=0.3, random_state=42)

# Step 5: Define and Evaluate Classifiers
classifiers = {
    "Logistic Regression": LogisticRegression(),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(),
    "SVM": SVC(),
    "XGBoost": XGBClassifier(use_label_encoder=False, eval_metric="logloss")  # Adjust for XGBoost warnings
}

# Train and evaluate each classifier
for name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    print(f"\nClassifier: {name}")
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, average='weighted'))
    print("Recall:", recall_score(y_test, y_pred, average='weighted'))
    print("F1 Score:", f1_score(y_test, y_pred, average='weighted'))
    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
    print("Classification Report:\n", classification_report(y_test, y_pred))
